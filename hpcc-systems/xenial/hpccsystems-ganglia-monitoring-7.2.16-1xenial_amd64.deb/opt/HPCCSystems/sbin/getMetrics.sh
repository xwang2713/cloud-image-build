#!/bin/bash

[[ -n $(/opt/HPCCSystems/sbin/configgen -env /etc/HPCCSystems/environment.xml  -listall2 -ip . -t roxie) ]] && /opt/HPCCSystems/bin/testsocket . -or "/tmp/.roxie_metrics" "<control:metrics/>" > /dev/null 2>&1
